Core Affinity Lab v13 — Signal Validation

For the existing Streamlit Cloud app, upload/replace this exact file in GitHub repo root:
core_affinity_lab_v1 (1).py

Run one stage at a time. Recommended order:
1 - Data audit + base profiles
2 - Core single-trait lift
3 - Member single-trait lift
4 - Core-vs-core separator validation
5 - Member-vs-member separator validation

Lab only. No daily playlist, no cuts, no RTE, no B1Z0, no ZLT, no rescue logic.
